import { Component, OnInit } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import { FormControl, FormGroup,Validators,FormBuilder } from '@angular/forms';
import { PasswordValidators } from "src/app/password-validators";
import { Router } from "@angular/router";
import { ConfirmPasswordValidator } from 'src/app/confirm-password-validator';
@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit{
  public updatePasswordForm!: FormGroup;
  public submitted:boolean=false;
  constructor(private _http:HttpClient, private router:Router, private formBuilder:FormBuilder){}
  ngOnInit(): void {
    this.updatePasswordForm=this.formBuilder.group({
      'email': new FormControl('', [Validators.email,Validators.required]),
      'adminId': new FormControl('', [Validators.required]),
      'password': new FormControl(null,
        Validators.compose([Validators.required,PasswordValidators.patternValidator({
        requiresValidExp: true
      })
        ])),
      'confirmPassword': new FormControl(null,
          Validators.compose([Validators.required,Validators.minLength(8)
          ]))
    },
    {
      validators:ConfirmPasswordValidator.passwordMatchValidator('password','confirmPassword')
    }
    )
   
  }

  // getter for easy access to form controls
  get passwordValid() {
    return this.updatePasswordForm.controls["password"].errors === null;
  }

  get requiredValid() {
    return !this.updatePasswordForm.controls["password"].hasError("required");
  }

  get expValid() {
    return !this.updatePasswordForm.controls["password"].hasError("requiresValidExp");
  }

  updatePassword(){
    this.submitted=true;
    this._http.patch<any>(`http://localhost:3000/admin/${this.updatePasswordForm.controls['adminId'].value}`,this.updatePasswordForm.controls['password'].value)
    .subscribe(res=>{
      const user = res.findById()
      alert('Password successfully updated');
      this.router.navigate(['login']);
      });
    }
  
  
}


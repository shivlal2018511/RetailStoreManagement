import {HttpClient} from "@angular/common/http";
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators } from '@angular/forms';
import { PasswordValidators } from "src/app/password-validators";
import { Router } from "@angular/router";
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit{
  public loginForm!: FormGroup;
  public submitted:boolean=false;
  constructor(private _http:HttpClient, private router:Router){}
  ngOnInit(): void {
    this.loginForm=new FormGroup({
      'email': new FormControl('', [Validators.email,Validators.required]),
      'password': new FormControl(null,
        Validators.compose([Validators.required,PasswordValidators.patternValidator({
        requiresValidExp: true
      })
        ]))
    })
   
  }

  // convenience getter for easy access to form controls
  // get f() {
  //   return this.loginForm.controls;
  // }

  get passwordValid() {
    return this.loginForm.controls["password"].errors === null;
  }

  get requiredValid() {
    return !this.loginForm.controls["password"].hasError("required");
  }

  get expValid() {
    return !this.loginForm.controls["password"].hasError("requiresValidExp");
  }

  loginData(){
    this.submitted=true;
    this._http.get<any>("http://localhost:3000/admin")
    .subscribe(res=>{
      const user=res.find((a:any)=>{
        return a.email=== this.loginForm?.value.email && a.password===this.loginForm?.value.password
      });

      if(user){
        alert('you are successfully login');
        //this.loginForm?.reset();
        this.router.navigate(['dashboard']);
      }
      else{
        alert('User Not Found');
      }
    },
    err=>{
      alert('Something went wrong');
    })
  }
  
}

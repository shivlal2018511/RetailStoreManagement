import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './admin/login/login.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { ForgotPasswordComponent } from './admin/forgot-password/forgot-password.component';
import { CustomerComponent } from './start-sell/customer/customer.component';
import { OrderListComponent } from './orders/order-list/order-list.component';
import { AddProductComponent } from './products/add-product/add-product.component';
import { ProductListComponent } from './products/product-list/product-list.component';
import { AddCategoryComponent } from './category/add-category/add-category.component';
import { ListCategoryComponent } from './category/list-category/list-category.component';
import { AddCompanyComponent } from './company/add-company/add-company.component';
import { CompanyListComponent } from './company/company-list/company-list.component';
import { CreateOrderComponent } from './orders/create-order/create-order.component';
import { EditCategoryComponent } from './category/edit-category/edit-category.component';
import { EditCompanyComponent } from './company/edit-company/edit-company.component';
import { EditProductComponent } from './products/edit-product/edit-product.component';

const routes:Routes=[
  {path:'login',component:LoginComponent},
  {path:'dashboard', component:DashboardComponent},
  {path:'add-customer', component:CustomerComponent},
  {path:'create-order', component:CreateOrderComponent},
  {path:'orders', component:OrderListComponent},
  {path:'add-product', component:AddProductComponent},
  {path:'products', component:ProductListComponent},
  {path:'edit-product/:id', component:EditProductComponent},
  {path:'add-category', component:AddCategoryComponent},
  {path:'category-list', component:ListCategoryComponent},
  {path:'edit-category/:id', component:EditCategoryComponent},
  {path:'add-company', component:AddCompanyComponent},
  {path:'company-list', component:CompanyListComponent},
  {path:'edit-company/:id', component:EditCompanyComponent},
  {path:'reset-password', component:ForgotPasswordComponent},
  {path:"", redirectTo:'/login',pathMatch:'full'},
  {path:'**',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

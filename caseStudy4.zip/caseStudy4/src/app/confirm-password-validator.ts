import {FormGroup} from '@angular/forms'
export class ConfirmPasswordValidator {
    static passwordMatchValidator(controlName: any, matchingControlName: any) {
        return (formGroup: FormGroup) => {
            let password = formGroup.controls[controlName];
            let confirmPassword = formGroup.controls[matchingControlName]
           
            if(confirmPassword.errors&& !confirmPassword.errors['MustMatch'])
            {
              return;
            }
              // compare the passwords and see if they match.
              if (password.value !== confirmPassword.value) {
               confirmPassword.setErrors({ mismatch: true });
              } else {
                // if passwords match, don't return an error.
                confirmPassword.setErrors(null);
              }
        
          }
      }
}

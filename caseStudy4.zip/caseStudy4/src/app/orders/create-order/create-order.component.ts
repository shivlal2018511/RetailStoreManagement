import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { StartSellService } from 'src/app/service/start-sell.service';

@Component({
  selector: 'app-create-order',
  templateUrl: './create-order.component.html',
  styleUrls: ['./create-order.component.css']
})
export class CreateOrderComponent {
customerName!:any;
customerMobile!:any;
orderId!:any;
orderDate!:any;
constructor(private sellService:StartSellService, private router:Router){}
  ngOnInit(){
    this.sellService.getCustomer().subscribe((res:any)=>{
      this.customerName = res[0].customerName;
      this.customerMobile = res[0].customerMobile;
       this.orderId = res[0].orderId;
      this.orderDate = res[0].orderDate;
    })
  }
}

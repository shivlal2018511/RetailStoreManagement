import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StartSellService {
   currentCustomer!:any;
   currentCustomerId:number = 100;
  constructor(private router:Router,private http:HttpClient) { }

  addCustomer(customerData:any):Observable<any>{
    return this.http.post<any>("http://localhost:3000/customers",customerData)
  }
  
  getCustomer():Observable<any>{
    this.currentCustomer = localStorage.getItem('currentCustomer');
  return this.http.get(`http://localhost:3000/customers?customerName=${this.currentCustomer}`);
  }
}

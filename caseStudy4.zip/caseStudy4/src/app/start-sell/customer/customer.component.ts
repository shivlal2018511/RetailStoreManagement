import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StartSellService } from 'src/app/service/start-sell.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent {
  addCustomerForm!:FormGroup;
   currentDateTime!:any;
  submitted:boolean=false;
  constructor(
    private datepipe: DatePipe,
     private formBuilder:FormBuilder, private sellService:StartSellService, private router:Router){
     this.currentDateTime =this.datepipe.transform((new Date), 'MM/dd/yyyy h:mm:ss');
  
  }
  ngOnInit(){
    this.addCustomerForm= this.formBuilder.group({
        customerName: new FormControl('', [Validators.minLength(5),Validators.required]),
        customerMobile: new FormControl('',[Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
        orderId:new FormControl(''),
        orderDate:new FormControl('')
    })
  }
addCustomer() {
   this.addCustomerForm.patchValue({orderId:this.sellService.currentCustomerId++, orderDate:this.currentDateTime});
   this.sellService.addCustomer(this.addCustomerForm.value).subscribe((res:any)=>{
    this.router.navigate(['/create-order'])
    localStorage.setItem('currentCustomer',this.addCustomerForm.controls['customerName'].value);
   }

   );
}

}


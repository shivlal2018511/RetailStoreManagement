import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup,Validators } from '@angular/forms';
import { PasswordValidators } from "src/app/password-validators";
import { Router } from "@angular/router";
import { AuthService } from "src/app/service/auth.service";
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit{
  public loginForm!: FormGroup;
  public submitted:boolean=false;
  constructor( private authService:AuthService, private router:Router){}
  ngOnInit(): void {
    this.loginForm=new FormGroup({
      'email': new FormControl('', [Validators.email,Validators.required]),
      'password': new FormControl(null,
        Validators.compose([Validators.required,PasswordValidators.patternValidator({
        requiresValidExp: true
      })
        ]))
    })
   
  }

  // convenience getter for easy access to form controls
  // get f() {
  //   return this.loginForm.controls;
  // }

  get passwordValid() {
    return this.loginForm.controls["password"].errors === null;
  }

  get requiredValid() {
    return !this.loginForm.controls["password"].hasError("required");
  }

  get expValid() {
    return !this.loginForm.controls["password"].hasError("requiresValidExp");
  }

  // loginData(){
  //   this.submitted=true;
  //   this._http.get<any>("http://localhost:3000/admin")
  //   .subscribe(res=>{
  //     const user=res.find((a:any)=>{
  //       return a.email=== this.loginForm?.value.email && a.password===this.loginForm?.value.password
  //     });

  //     if(user){
  //       alert('you are successfully login');
  //       //this.loginForm?.reset();
  //       this.router.navigate(['dashboard']);
  //     }
  //     else{
  //       alert('User Not Found');
  //     }
  //   },
  //   err=>{
  //     alert('Something went wrong');
  //   })
  // }
  
  loginData(){
    this.submitted=true;
    if (this.loginForm.invalid) {
      return;
    }
    this.authService.login(this.loginForm.controls["email"].value).subscribe((res:any)=>{
      console.log(res[0].email);
      if(res[0].email=== this.loginForm.controls["email"].value && res[0].password=== this.loginForm.controls['password'].value)
      {
        
        localStorage.setItem("userName",res[0].name);
       this.router.navigate(['/dashboard'])
      }
      else{
        alert('Email or password is wrong');
      }
      } 
      )
    
  }
  
}



import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CategoryService } from 'src/app/service/category.service';
@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent {
  categoryAddForm!:FormGroup;
  submitted:boolean=false;
constructor(private formBuilder:FormBuilder,private categoryService: CategoryService, private router:Router){}
ngOnInit(){
  this.categoryAddForm= this.formBuilder.group({
    categoryName: new FormControl('',[Validators.required, Validators.minLength(3)]),
    categoryDesc: new FormControl('',[Validators.required, Validators.maxLength(300)])
  })
}
addCategory(){
  this.submitted=true;
  this.categoryService.addCategory(this.categoryAddForm.value).subscribe((res:any)=>{
      alert('New category added');
      this.router.navigate(['/category-list'])
  })
  
}
}

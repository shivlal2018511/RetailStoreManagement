import { Component } from '@angular/core';
import { CategoryService } from 'src/app/service/category.service';
@Component({
  selector: 'app-list-category',
  templateUrl: './list-category.component.html',
  styleUrls: ['./list-category.component.css']
})
export class ListCategoryComponent {

   categoryId!:any;
  categoryName!:any;
   categoryDesc!:any;
categories!: Array<any>;

   constructor(private categoryService: CategoryService){
     
   }
   ngOnInit(){
    this.getCategoryDetails();
   }
   getCategoryDetails(){
    this.categoryService.getCategories().subscribe((res:any)=>{
        //  this.categoryId= res[0].id;
        //  this.categoryName= res[0].categoryName;
        //  this.categoryDesc = res[0].categoryDesc;
        this.categories = res;
    })
   }
   deleteCategory(id:any) {
     this.categoryService.deleteCategory(id).subscribe((res:any)=>{
      this.getCategoryDetails();
      alert('category deleted successfully')
     })
   }
   
}

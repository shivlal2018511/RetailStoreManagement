import { Component } from '@angular/core';
import { CompanyService } from 'src/app/service/company.service';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.css']
})
export class CompanyListComponent {
  companyId!:any;
  companyName!:any;
   companyDesc!:any;
companies!: Array<any>;
   constructor(private companyService:CompanyService){}
   ngOnInit(){
    this.getCompanyDetails();
   }
   getCompanyDetails(){
    this.companyService.getCompanies().subscribe((res:any)=>{
        this.companies = res;
    })
   }
   deleteCompany(id:any) {
     this.companyService.deleteCompany(id).subscribe((res:any)=>{
      this.getCompanyDetails();
      alert('category deleted successfully')
     })
   }
}

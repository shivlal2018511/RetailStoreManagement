import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CompanyService } from 'src/app/service/company.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-edit-company',
  templateUrl: './edit-company.component.html',
  styleUrls: ['./edit-company.component.css']
})
export class EditCompanyComponent {
  companyEditForm!:FormGroup;
  submitted:boolean=false;
  companyId!:any;
constructor(private formBuilder:FormBuilder,private companyService: CompanyService, private router:Router, private route:ActivatedRoute){}
ngOnInit(){
  this.route.params.subscribe((param)=>{
    this.companyId = param['id']
  })
  this.companyEditForm= this.formBuilder.group({
    companyName: new FormControl('',[Validators.required, Validators.minLength(2)]),
    companyDesc: new FormControl('',[Validators.required, Validators.maxLength(300)])
  })
}
updateCompany(){
  this.submitted=true;
  this.companyService.updateCompany(this.companyId, this.companyEditForm.value).subscribe((res:any)=>{
      alert('Company details updated');
      this.router.navigate(['/company-list'])
  })
  
}
}

import {AbstractControl, ValidationErrors, ValidatorFn} from "@angular/forms"
export class NumberValidator {
    constructor(){}
    static numberPatternValidator(error:ValidationErrors):ValidatorFn{
        return (control:AbstractControl):{ [key: string]: boolean }|null => {
            if(!control.value){
                return null;
            }
            const regex= new RegExp('/^\d+$/');
            const valid = regex.test(control.value);
            return valid?null:error;
        }
    }

    
}

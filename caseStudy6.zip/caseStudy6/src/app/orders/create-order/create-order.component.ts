import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { StartSellService } from 'src/app/service/start-sell.service';
import { ProductService } from 'src/app/service/product.service';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-create-order',
  templateUrl: './create-order.component.html',
  styleUrls: ['./create-order.component.css']
})
export class CreateOrderComponent {
  custOrderDetails!:any;
customerName!:any;
customerMobile!:any;
orderId!:any;
orderDate!:any;
ordersAddForm!:any;
submitted:boolean=false;
customerId!:any;
//product details
pdtId!:any;
pdtPrice!:number;
totalProductCost!:number;
orderCost:number=0;
//products array to show available products
products!:Array<any>;
constructor(private sellService:StartSellService, 
  private router:Router, 
  private productService:ProductService,
  private formBuilder:FormBuilder
  ){}
  ngOnInit(){
      this.getProducts();

    this.sellService.getCustomer().subscribe((res:any)=>{
      this.customerId = res[0].id;
      this.customerName = res[0].customerName;
      this.customerMobile = res[0].customerMobile;
       this.orderId = res[0].orderId;
      this.orderDate = res[0].orderDate;
    });

    //order values
    this.ordersAddForm = this.formBuilder.group({
      customerName: new FormControl(''),
      customerMobile:new FormControl(null),
      orderId : new FormControl(''),
      orderDate: new FormControl(null),
      productId:new FormControl(''),
      availableProducts: new FormControl(null ,[Validators.required] ),
      productPrice: new FormControl(null),
      orderQuantity: new FormControl(null, [Validators.required]),
      totalProductCost:new FormControl(0),
      
    })
    this.getProductByName();
  }

  getProducts(){
    this.productService.getProducts().subscribe((res:any)=>{
        this.products = res;
    })
   }

   getProductByName(){
      this.productService.getProductByName(this.ordersAddForm.controls['availableProducts'].value).subscribe((res:any)=>{
          this.pdtId = res[0].id;
          this.pdtPrice = res[0].productPrice; 
      })
      this.getTotalProductCost();
   }
   
   getTotalProductCost(){
       this.totalProductCost = this.pdtPrice * this.ordersAddForm.controls['orderQuantity'].value;
   }

   getOrderDetails(){
    this.sellService.getOrderByCustomerName(this.customerName).subscribe((res:any)=>{
        this.custOrderDetails = res;
    })
   }
  addOrder(){
    this.submitted = true;
    this.getProductByName();
    this.ordersAddForm.patchValue({customerName:`${this.customerName}`,customerMobile:this.customerMobile,orderId:this.orderId,orderDate:this.orderDate,productId:`${this.pdtId}`, productPrice:this.pdtPrice,totalProductCost:this.totalProductCost});
  
    this.orderCost=(this.orderCost + this.ordersAddForm.controls['totalProductCost'].value);
    this.sellService.addOrder(this.ordersAddForm.value).subscribe((res:any)=>{
      alert('New order placed');
  })
  this.getOrderDetails()

  }

  deleteOrder(id:any){
    this.sellService.getOrder(id).subscribe((res:any)=>{
      this.orderCost = this.orderCost - res.totalProductCost;
    })
    this.sellService.deleteOrder(id).subscribe((res)=>{
      this.getOrderDetails()
      
      alert('order deleted successfully');
    })
  }

saveSell(){
  this.sellService.updateCustomer(this.customerId,{orderCost:this.orderCost}).subscribe((res:any)=>{})
}

}

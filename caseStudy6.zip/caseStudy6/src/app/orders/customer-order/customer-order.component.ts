import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { StartSellService } from 'src/app/service/start-sell.service';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-customer-order',
  templateUrl: './customer-order.component.html',
  styleUrls: ['./customer-order.component.css']
})
export class CustomerOrderComponent {
  //product details
  customerName!:any;
  customerMobile!:any;
  orderId!:any;
  orderDate!:any;
  custOrderDetails!:Array<any>;
  
  orderCost:number=0;
  //products array to show available products
  products!:Array<any>;
  constructor(private sellService:StartSellService, 
    private router:Router, 
    private productService:ProductService,
    ){
      this.customerName = localStorage.getItem('currentCustomer')
    }
    ngOnInit(){
        this.getOrderDetails()
        this.sellService.getCustomer().subscribe((res:any)=>{
          this.customerName = res[0].customerName;
          this.customerMobile = res[0].customerMobile;
           this.orderId = res[0].orderId;
          this.orderDate = res[0].orderDate;
          this.orderCost = res[0].orderCost;
        });
    }
  
     getOrderDetails(){
      this.sellService.getOrderByCustomerName(this.customerName).subscribe((res:any)=>{
          this.custOrderDetails = res;
          console.log(res)
      })
     }
  }
  
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { StartSellService } from 'src/app/service/start-sell.service';
import { ProductService } from 'src/app/service/product.service';
import { map } from 'rxjs';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.css']
})
export class OrderListComponent {
 //product details
 customers!:Array<any>;
 orderId!:any;
 orderDate!:any;
 custOrderDetails:Array<any>=[];
 
 orderCost:number=0;
 //
 tempOrderDetails!:any;
 //products array to show available products
 products!:Array<any>;
 constructor(private sellService:StartSellService, 
   private router:Router, 
   private productService:ProductService,
   ){
    
   }
   ngOnInit(){
    this.getCustomers();
   
}

getCustomers(){
  this.sellService.getCustomers().subscribe((res:any)=>{
    this.customers = res;
    this.getOrderDetails()
    
  })
  
  
}
 getOrderDetails(){

  
  this.customers.forEach((customer)=>{
       this.sellService.getOrderByCustomerName(customer.customerName).subscribe((res:any)=>{
       const orderDetails = res[0];
       
       console.log(orderDetails)
       this.custOrderDetails.push(res[0]); 
  })
  //console.log(this.custOrderDetails)
  
 })

 }
}
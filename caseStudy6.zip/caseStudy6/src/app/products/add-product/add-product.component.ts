import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CategoryService } from 'src/app/service/category.service';
import { CompanyService } from 'src/app/service/company.service';
import { ProductService } from 'src/app/service/product.service';
@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent {

   constructor(private formBuilder:FormBuilder,
    private router:Router,
    private productService:ProductService,
    private companyService:CompanyService,
    private categoryService:CategoryService){}

   productAddForm!:any;
   submitted:boolean=false;
   productCategories!:Array<any>;
   productCompanies!:Array<any>;
   ngOnInit(){
    this.getCategories();
    this.getCompanies();
    this.productAddForm= this.formBuilder.group({
      productCode: new FormControl('',[Validators.required]),
      productName: new FormControl('',[Validators.required, Validators.minLength(2)]),
       productCategory: new FormControl(null ,[Validators.required] ),
       productCompany: new FormControl(null,[Validators.required]),
       productStock: new FormControl(null,[Validators.required,Validators.min(2), Validators.max(100)]),
       productPrice: new FormControl(null,[Validators.required,Validators.min(1)]),
       productMfgDate: new FormControl('',[Validators.required, 
      // Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)
      ]),
      productExpDate: new FormControl('',[Validators.required]),
      productDesc:new FormControl('',[Validators.required,Validators.maxLength(200)])
    });
   }

  //  get expValid() {
  //   return !this.productAddForm.controls["productStock"].hasError("requiresValidNumExp");
  // }
   getCompanies(){
    this.companyService.getCompanies().subscribe((res:any)=>{
        this.productCompanies = res;
    })
    
   }

   getCategories(){
    this.categoryService.getCategories().subscribe((res:any)=>{
        this.productCategories = res;
        
    })
    
   }

   addProduct(){
    this.submitted=true;
    this.productService.addProduct(this.productAddForm.value).subscribe((res:any)=>{
        alert('New product added');
        this.router.navigate(['/products'])
    })
   
  }
}

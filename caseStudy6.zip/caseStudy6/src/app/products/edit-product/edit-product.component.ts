import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CategoryService } from 'src/app/service/category.service';
import { CompanyService } from 'src/app/service/company.service';
import { ProductService } from 'src/app/service/product.service';
@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent {

  constructor(private formBuilder:FormBuilder,
    private router:Router,
    private productService:ProductService,
    private companyService:CompanyService,
    private categoryService:CategoryService,
    private route:ActivatedRoute){}

   productEditForm!:any;
   productId!:any;
   submitted:boolean=false;
   productCategories!:Array<any>;
   productCompanies!:Array<any>;
   ngOnInit(){
    this.route.params.subscribe((param)=>{
      this.productId = param['id']
    })
    this.getCategories();
    this.getCompanies();
    this.productEditForm= this.formBuilder.group({
      productCode: new FormControl('',[Validators.required]),
      productName: new FormControl('',[Validators.required, Validators.minLength(2)]),
       productCategory: new FormControl(null ,[Validators.required] ),
       productCompany: new FormControl(null,[Validators.required]),
       productStock: new FormControl(null,[Validators.required,Validators.min(2), Validators.max(100)]),
       productPrice: new FormControl(null,[Validators.required,Validators.min(1)]),
       productMfgDate: new FormControl('',[Validators.required, 
      ]),
      productExpDate: new FormControl('',[Validators.required]),
      productDesc:new FormControl('',[Validators.required,Validators.maxLength(200)])
    });
   }

   getCompanies(){
    this.companyService.getCompanies().subscribe((res:any)=>{
        this.productCompanies = res;
    })
    
   }

   getCategories(){
    this.categoryService.getCategories().subscribe((res:any)=>{
        this.productCategories = res;
        
    })
    
   }

   editProduct(){
    this.submitted=true;
    this.productService.updateProduct(this.productId,this.productEditForm.value).subscribe((res:any)=>{
        alert('Product updated');
        this.router.navigate(['/products'])
    })
   
  }
}


import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  constructor(private router:Router,private http:HttpClient) { }
  addCompany(companyData: any):Observable<any>{
    
    return this.http.post<any>("http://localhost:3000/companies",companyData)
  }
  getCompany(id:any):Observable<any>{
    
    return this.http.get<any>("http://localhost:3000/companies"+id)
  }
  getCompanies():Observable<any>{
    
    return this.http.get<any>("http://localhost:3000/companies")
  }
  deleteCompany(id:any){
    return this.http.delete<any>(`http://localhost:3000/companies/${id}`)
  }
  updateCompany(id:any,newCompanyData:any){
    return this.http.put<any>(`http://localhost:3000/companies/${id}`,newCompanyData);
  }

}

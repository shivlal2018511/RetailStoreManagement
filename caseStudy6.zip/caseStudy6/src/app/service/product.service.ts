import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private router:Router,private http:HttpClient) { }
  addProduct(productData: any):Observable<any>{
    
    return this.http.post<any>("http://localhost:3000/products",productData)
  }
  getProduct(id:any):Observable<any>{
    
    return this.http.get<any>("http://localhost:3000/products/"+id)
  }
  getProducts():Observable<any>{
    
    return this.http.get<any>("http://localhost:3000/products")
  }
  deleteProduct(id:any){
    return this.http.delete<any>(`http://localhost:3000/products/${id}`)
  }
  updateProduct(id:any,newProductData:any){
    return this.http.put<any>(`http://localhost:3000/products/${id}`,newProductData);
  }
  getProductByName(name:any):Observable<any>{
    return this.http.get(`http://localhost:3000/products?name=${name}`);
  }
}

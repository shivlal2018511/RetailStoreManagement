import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StartSellService {
   currentCustomer!:any;
  
  constructor(private router:Router,private http:HttpClient) { }

  addCustomer(customerData:any):Observable<any>{
    return this.http.post<any>("http://localhost:3000/customers",customerData)
  }
  updateCustomer(id:any,property:any):Observable<any>{
    return this.http.patch("http://localhost:3000/customers/"+id, property)
  }
  getCustomer():Observable<any>{
    this.currentCustomer = localStorage.getItem('currentCustomer');
  return this.http.get(`http://localhost:3000/customers?customerName=${this.currentCustomer}`);
  }
  getCustomers():Observable<any>{
    return this.http.get("http://localhost:3000/customers")
  }

  addOrder(orderData:any):Observable<any>{
    return this.http.post<any>("http://localhost:3000/orders",orderData)
  }
  getOrders():Observable<any>{
    return this.http.get<any>("http://localhost:3000/orders")
  }
  getOrder(id:any){
    return this.http.get(`http://localhost:3000/orders/${id}`)
  }
  getOrderByCustomerName(name:any){
    return this.http.get(`http://localhost:3000/orders?customerName=${name}`)
  }
  getOrderByOrderId(id:any){
    return this.http.get(`http://localhost:3000/orders?orderId=${id}`)
  }
  deleteOrder(id:any){
    return this.http.delete<any>(`http://localhost:3000/orders/${id}`)
  }
  updateOrder(id:any,newOrderData:any){
    return this.http.put<any>(`http://localhost:3000/orders/${id}`,newOrderData);
  }
  
}

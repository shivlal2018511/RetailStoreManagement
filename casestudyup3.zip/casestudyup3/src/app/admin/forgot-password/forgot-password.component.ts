import { Component, OnInit } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import { FormControl, FormGroup,Validators,FormBuilder } from '@angular/forms';
import { PasswordValidators } from "src/app/password-validators";
import { Router } from "@angular/router";
import { ConfirmPasswordValidator } from 'src/app/confirm-password-validator';
import { AuthService } from 'src/app/service/auth.service';
@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit{
  public updatePasswordForm!: FormGroup;
  public updatedAdminData!:FormGroup;
  data!:any;
  public submitted:boolean=false;
  constructor(private authService:AuthService, private formBuilder:FormBuilder, private router:Router){
   
  }
  ngOnInit(): void {
    this.updatePasswordForm=this.formBuilder.group({
      'email': new FormControl('', [Validators.email,Validators.required]),
      'password': new FormControl(null,
        Validators.compose([Validators.required,PasswordValidators.patternValidator({
        requiresValidExp: true
      })
        ])),
      'confirmPassword': new FormControl(null,
          Validators.compose([Validators.required,Validators.minLength(8)
          ]))
    },
    {
      validators:ConfirmPasswordValidator.passwordMatchValidator('password','confirmPassword')
    }
    )
   
    this.updatedAdminData=this.formBuilder.group({
      id:new FormControl(''),
      name:new FormControl(''),
      email: new FormControl(''),
      password:new FormControl('')
    })
  }

  // getter for easy access to form controls
  get passwordValid() {
    return this.updatePasswordForm.controls["password"].errors === null;
  }

  get requiredValid() {
    return !this.updatePasswordForm.controls["password"].hasError("required");
  }

  get expValid() {
    return !this.updatePasswordForm.controls["password"].hasError("requiresValidExp");
  }
  getData(){
    this.submitted=true;
    this.authService.login(this.updatePasswordForm.controls['email'].value).subscribe((res:any)=>{
      this.data = res[0];
     
      this.updatedAdminData.patchValue({id:`${this.data.id}`,name:`${this.data.name}`,email:`${this.data.email}`,password:`${this.updatePasswordForm.controls['password'].value}`})
      
      this.authService.updatePassword(this.updatedAdminData.controls['id'].value,this.updatedAdminData.value).subscribe((res:any)=>{
        console.log(res);
        alert('Password updated successfully')
     })
 })
  }
  getUpdatedAdminData(){
    this.submitted=true; 
   // this.updatedAdminData.patchValue({id:`${this.data.id}`,name:`${this.data.name}`,email:`${this.data.email}`,password:`${this.updatePasswordForm.controls['password'].value}`})
     // console.log(this.updatedAdminData.controls['email'].value)
      
   // this.authService.updatePassword(this.updatePasswordForm.controls['id'].value,this.updatePasswordForm.value).subscribe((res:any)=>{
      //console.log(res);
     // alert('Password updated successfully')
   // })
  }
  // updatePassword(){
  //   this.submitted=true;
    
  //   this.authService.updatePassword(this.updatePasswordForm.controls['email'].value,this.updatePasswordForm.controls['password']).subscribe(res=>{
  //     alert('Password successfully updated');
  //     this.router.navigate(['login']);
  //     });
  //   }
  
  
}


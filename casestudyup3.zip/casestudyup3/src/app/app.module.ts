import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './admin/login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { ForgotPasswordComponent } from './admin/forgot-password/forgot-password.component';
import { CustomerComponent } from './start-sell/customer/customer.component';
import { OrderListComponent } from './orders/order-list/order-list.component';
import { AddProductComponent } from './products/add-product/add-product.component';
import { ProductListComponent } from './products/product-list/product-list.component';
import { AddCategoryComponent } from './category/add-category/add-category.component';
import { ListCategoryComponent } from './category/list-category/list-category.component';
import { AddCompanyComponent } from './company/add-company/add-company.component';
import { CompanyListComponent } from './company/company-list/company-list.component';
import { RsmNavbarComponent } from './common/rsm-navbar/rsm-navbar.component';
import { SideNavComponent } from './common/side-nav/side-nav.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    DashboardComponent,
    ForgotPasswordComponent,
    CustomerComponent,
    OrderListComponent,
    AddProductComponent,
    ProductListComponent,
    AddCategoryComponent,
    ListCategoryComponent,
    AddCompanyComponent,
    CompanyListComponent,
    RsmNavbarComponent,
    SideNavComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

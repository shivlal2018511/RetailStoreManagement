import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RsmNavbarComponent } from './rsm-navbar.component';

describe('RsmNavbarComponent', () => {
  let component: RsmNavbarComponent;
  let fixture: ComponentFixture<RsmNavbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RsmNavbarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RsmNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { CategoryService } from 'src/app/service/category.service';
@Component({
  selector: 'app-edit-category',
  templateUrl: './edit-category.component.html',
  styleUrls: ['./edit-category.component.css']
})
export class EditCategoryComponent {
  categoryEditForm!:FormGroup;
  submitted:boolean=false;
  categoryId!:any;
  constructor(private formBuilder:FormBuilder,private categoryService: CategoryService, private router:Router, private route:ActivatedRoute){}
  ngOnInit(){ this.route.params.subscribe((param)=>{
    this.categoryId = param['id']
  })
  this.categoryEditForm= this.formBuilder.group({
    categoryName: new FormControl('',[Validators.required, Validators.minLength(2)]),
    categoryDesc: new FormControl('',[Validators.required, Validators.maxLength(300)])
  })
}
updateCategory(){
  this.submitted=true;
  this.categoryService.updateCategory(this.categoryId, this.categoryEditForm.value).subscribe((res:any)=>{
      alert('Company details updated');
      this.router.navigate(['/category-list'])
  })
  
}
}

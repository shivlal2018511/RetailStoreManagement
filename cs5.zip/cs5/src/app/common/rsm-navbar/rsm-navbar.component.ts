import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/service/auth.service';
@Component({
  selector: 'app-rsm-navbar',
  templateUrl: './rsm-navbar.component.html',
  styleUrls: ['./rsm-navbar.component.css']
})
export class RsmNavbarComponent {
  public userName!:any;

  constructor(private router:Router, private authService:AuthService){}
  ngOnInit(){
   
    this.getAdmin();
   }
  getAdmin(){
    this.authService.getAdminData().subscribe((res:any)=>{
      this.userName= res[0].name;
    })
  }
  logout(){
    this.authService.logout()
  }
}

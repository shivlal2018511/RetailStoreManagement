import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CompanyService } from 'src/app/service/company.service';

@Component({
  selector: 'app-add-company',
  templateUrl: './add-company.component.html',
  styleUrls: ['./add-company.component.css']
})
export class AddCompanyComponent {
  companyAddForm!:FormGroup;
  submitted:boolean=false;
constructor(private formBuilder:FormBuilder,private companyService: CompanyService, private router:Router){}
ngOnInit(){
  this.companyAddForm= this.formBuilder.group({
    companyName: new FormControl('',[Validators.required, Validators.minLength(2)]),
    companyDesc: new FormControl('',[Validators.required, Validators.maxLength(300)])
  })
}
addCompany(){
  this.submitted=true;
  this.companyService.addCompany(this.companyAddForm.value).subscribe((res:any)=>{
      alert('New company added');
      this.router.navigate(['/company-list'])
  })
  
}
}

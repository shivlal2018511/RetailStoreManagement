import { Component } from '@angular/core';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {
  products!: Array<any>;
  id!:any;
  productCode!:any;
  productName!:any;
  productCategory!:any;
  productCost!:any;
  
 constructor(private productService:ProductService){}
 ngOnInit(){
  this.getProductDetails();
 }
 getProductDetails(){
  this.productService.getProducts().subscribe((res:any)=>{
      this.products = res;
  })
 }
 deleteProduct(id:any) {
  this.productService.deleteProduct(id).subscribe((res:any)=>{
   this.getProductDetails();
   alert('Product deleted successfully')
  })
}
}

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  constructor(private router:Router,private http:HttpClient) { }
  addCategory(categoryData: any):Observable<any>{
    console.log(categoryData);
    return this.http.post<any>("http://localhost:3000/categories",categoryData)
  }
  getCategories():Observable<any>{
    
    return this.http.get<any>("http://localhost:3000/categories")
  }
  deleteCategory(id:any){
    return this.http.delete<any>(`http://localhost:3000/categories/${id}`)
  }
  updateCategory(id:any,newCategoryData:any){
    return this.http.put<any>(`http://localhost:3000/categories/${id}`,newCategoryData);
  }
}

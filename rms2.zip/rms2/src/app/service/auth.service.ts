import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private router:Router,private http:HttpClient) { }
  signup(signupData: any):Observable<any>{
    console.log(signupData);
    return this.http.post<any>("http://localhost:3000/admins",signupData)
  }
  login(email:any):Observable<any> {
   return this.http.get<any>(`http://localhost:3000/admins?email=${email}`)
  }

  getAdminData():Observable<any>{
    const name = localStorage.getItem('userName');
    return this.http.get<any>(`http://localhost:3000/admins?name=${name}`);
  }
  logout(){
    localStorage.removeItem('userName');
    this.router.navigate(['/login'])
  }
}
